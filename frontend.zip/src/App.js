import { BrowserRouter as Router , Routes ,Route , Navigate } from "react-router-dom";
import './App.css';
import Dashbord from "./components/Dashbord";
import Loginform from './components/Loginform';
import Signup from './components/Signup';

function App() {

    const user = localStorage.getItem("token");

	
  return (
   <Router>
    <Routes>
    {user && <Route path="/" exact element={<Dashbord />} />}
			<Route path="/signup" exact element={<Signup />} />
			<Route path="/loginform" exact element={<Loginform />} />
			<Route path="/" element={<Navigate replace to="/loginform" />} />
    </Routes>
   </Router>
 );
}

export default App;


