const router = require("express").Router();
const {createuser} = require("../controllers/user");


router.post("/", createuser);



module.exports = router;